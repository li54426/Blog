---
layout: post
category: bash_automation
title:  
date:   2024-04-06 13:53:18
tags:
- automation
- bash
banner:
 image: https://bit.ly/3xTmdUP
---

* content
{:toc}
![image-20240406135341418](assets/image-20240406135341418.png)
