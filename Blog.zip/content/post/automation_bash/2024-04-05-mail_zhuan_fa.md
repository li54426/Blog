---
layout: post
banana: true
category: bash_automation
title:  邮件设置转发
date:   2024-04-05 23:09:34
banner:
 image: https://bit.ly/3xTmdUP
tags:
- automation
- bash
---









#### 1 邮件设置转发

- 进入邮箱（例如126，QQ邮箱等），点击`设置`选择`转发`选项，
- 然后填写转发的目的邮箱就行



#### 2 邮件设置短信提醒

- 进入`139`邮箱APP（因为移动作为运营商，其业务范围一定包括短信，且该项业务免费）
- 右下角`我的`，打开`设置`
- 选择`邮件到达通知`





